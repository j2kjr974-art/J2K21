# Obtenir l'APK J2K' Launcher

Le fichier APK n'a pas pu être compilé dans l'environnement actuel : Android SDK et Gradle
ne sont pas installés et l'accès réseau nécessaire à leur installation n'est pas disponible.

## Compilation avec Android Studio
1. Installer Android Studio et JDK 17.
2. Ouvrir le dossier `J2K_Launcher_v2`.
3. Laisser Gradle synchroniser le projet.
4. Choisir **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Récupérer `app/build/outputs/apk/debug/app-debug.apk`.

## Compilation automatique avec GitHub Actions
Le workflow `.github/workflows/android-apk.yml` compile l'APK à chaque push sur `main`/`master`
et aussi manuellement depuis l'onglet **Actions**. Le fichier se récupère dans les **Artifacts**
du lancement du workflow.
