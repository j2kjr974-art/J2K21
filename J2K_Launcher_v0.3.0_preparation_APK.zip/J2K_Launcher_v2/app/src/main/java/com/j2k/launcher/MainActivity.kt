package com.j2k.launcher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.util.Base64
import java.util.Properties
import java.util.zip.ZipInputStream

private val Bg = Color(0xFF080D0A)
private val Panel = Color(0xFF121B15)
private val Green = Color(0xFF39D879)
private val Muted = Color(0xFF91A398)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { J2KApp() }
    }
}

data class ModPack(val folder: File) {
    val id get() = folder.name
    val name get() = folder.name.replace('_', ' ')
    val files get() = folder.walkTopDown().filter { it.isFile && it.name != "j2k.properties" }.toList()
    val installed get() = File(folder, ".j2k-installed.properties").exists()
    val category: String get() {
        val props = Properties()
        File(folder, "j2k.properties").takeIf { it.exists() }?.inputStream()?.use { props.load(it) }
        return props.getProperty("category", "Divers").ifBlank { "Divers" }
    }
}

@Composable
fun J2KApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("j2k", 0) }
    val scope = rememberCoroutineScope()
    var page by remember { mutableStateOf("home") }
    var version by remember { mutableStateOf(prefs.getString("version", "0.3.7") ?: "0.3.7") }
    var gameTree by remember { mutableStateOf(prefs.getString("game_tree", null)?.let(Uri::parse)) }
    var nickname by remember { mutableStateOf(prefs.getString("nickname", "") ?: "") }
    var server by remember { mutableStateOf(prefs.getString("server", "") ?: "") }
    var package037 by remember { mutableStateOf(prefs.getString("pkg037", "com.sampmobilerp.game") ?: "com.sampmobilerp.game") }
    var packageDl by remember { mutableStateOf(prefs.getString("pkgDl", "com.sa.mp") ?: "com.sa.mp") }
    var packs by remember { mutableStateOf(loadPacks(context)) }
    var status by remember { mutableStateOf("Prêt") }
    var busy by remember { mutableStateOf(false) }

    fun refresh() { packs = loadPacks(context) }

    val gamePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                gameTree = uri
                prefs.edit().putString("game_tree", uri.toString()).apply()
                status = "Dossier du jeu enregistré"
            } catch (e: Exception) { status = "Autorisation impossible : ${e.message}" }
        }
    }

    val zipPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val result = withContext(Dispatchers.IO) { importZip(context, uri) }
            status = result
            refresh()
            busy = false
        }
    }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val result = withContext(Dispatchers.IO) { importFolder(context, uri) }
            status = result
            refresh()
            busy = false
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green, background = Bg, surface = Panel, onPrimary = Color.Black,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("home" to Icons.Default.Home, "versions" to Icons.Default.SwapHoriz,
                    "mods" to Icons.Default.Extension, "settings" to Icons.Default.Settings).forEach { (key, icon) ->
                    NavigationBarItem(
                        selected = page == key, onClick = { page = key },
                        icon = { Icon(icon, null) }, label = { Text(key.uppercase()) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Green, selectedTextColor = Green,
                            indicatorColor = Color(0xFF1B3A27), unselectedTextColor = Muted
                        )
                    )
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("J2K'", color = Green, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("LAUNCHER", fontWeight = FontWeight.Bold)
                        Text("GTA SAN ANDREAS MOBILE", color = Muted, style = MaterialTheme.typography.labelSmall)
                    }
                }
                Spacer(Modifier.height(20.dp))
                when (page) {
                    "home" -> {
                        Text("CENTRE DE LANCEMENT", color = Muted, style = MaterialTheme.typography.labelMedium)
                        Spacer(Modifier.height(12.dp))
                        CardBox {
                            Text("CLIENT SÉLECTIONNÉ", color = Muted)
                            Text(version, color = Green, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                            Text(if (gameTree == null) "Dossier GTA non sélectionné" else "Dossier GTA configuré", color = Muted)
                        }
                        Spacer(Modifier.height(14.dp))
                        Button(onClick = {
                            val pkg = if (version == "0.3.7") package037.trim() else packageDl.trim()
                            val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
                            if (launchIntent != null) context.startActivity(launchIntent)
                            else status = "Client introuvable : vérifie le package Android dans Paramètres."
                        }, modifier = Modifier.fillMaxWidth().height(56.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                            Text("JOUER", color = Color.Black, fontWeight = FontWeight.ExtraBold)
                        }
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(onClick = { gamePicker.launch(gameTree) }, modifier = Modifier.fillMaxWidth()) {
                            Text("CHOISIR LE DOSSIER GTA")
                        }
                        Spacer(Modifier.height(14.dp))
                        Text(status, color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                    "versions" -> {
                        PageTitle("VERSIONS", "Les deux clients sont installés séparément")
                        listOf("0.3.7", "0.3.DL").forEach { v ->
                            SelectCard(v, version == v) {
                                version = v
                                prefs.edit().putString("version", v).apply()
                            }
                        }
                        Text("Le bouton JOUER ouvre le package configuré pour la version sélectionnée.", color = Muted)
                    }
                    "mods" -> {
                        PageTitle("GESTION DES MODS", "Importe, installe et restaure tes packs")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) },
                                modifier = Modifier.weight(1f), enabled = !busy) { Text("IMPORT ZIP") }
                            OutlinedButton(onClick = { folderPicker.launch(null) },
                                modifier = Modifier.weight(1f), enabled = !busy) { Text("IMPORT DOSSIER") }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("Catégories : véhicules, skins, textures, HUD, effets, graphismes.", color = Muted, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(10.dp))
                        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                        if (packs.isEmpty()) Text("Aucun pack importé.", color = Muted)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            items(packs, key = { it.id }) { pack ->
                                CardBox {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.FolderZip, null, tint = Green)
                                        Spacer(Modifier.width(9.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(pack.name, fontWeight = FontWeight.SemiBold)
                                            Text("${pack.category} • ${pack.files.size} fichiers", color = Muted, style = MaterialTheme.typography.bodySmall)
                                        }
                                        Text(if (pack.installed) "ACTIF" else "INACTIF",
                                            color = if (pack.installed) Green else Muted, style = MaterialTheme.typography.labelSmall)
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        if (!pack.installed) {
                                            Button(onClick = {
                                                val tree = gameTree
                                                if (tree == null) status = "Sélectionne d'abord le dossier GTA."
                                                else scope.launch {
                                                    busy = true
                                                    status = withContext(Dispatchers.IO) { installPack(context, tree, pack) }
                                                    refresh(); busy = false
                                                }
                                            }, modifier = Modifier.weight(1f), enabled = !busy) { Text("INSTALLER") }
                                        } else {
                                            Button(onClick = {
                                                val tree = gameTree
                                                if (tree == null) status = "Dossier GTA manquant."
                                                else scope.launch {
                                                    busy = true
                                                    status = withContext(Dispatchers.IO) { uninstallPack(context, tree, pack) }
                                                    refresh(); busy = false
                                                }
                                            }, modifier = Modifier.weight(1f), enabled = !busy) { Text("RESTAURER") }
                                        }
                                        OutlinedButton(onClick = {
                                            if (pack.installed) status = "Désinstalle le pack avant de le supprimer."
                                            else { pack.folder.deleteRecursively(); refresh(); status = "Pack supprimé." }
                                        }, enabled = !busy) { Text("SUPPRIMER") }
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(status, color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                    else -> {
                        PageTitle("PARAMÈTRES", "Clients externes et stockage SAF")
                        OutlinedTextField(value = nickname, onValueChange = {
                            nickname = it; prefs.edit().putString("nickname", it).apply()
                        }, label = { Text("Pseudo") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = server, onValueChange = {
                            server = it; prefs.edit().putString("server", it).apply()
                        }, label = { Text("Serveur (IP:port)") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = package037, onValueChange = {
                            package037 = it; prefs.edit().putString("pkg037", it).apply()
                        }, label = { Text("Package client 0.3.7") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = packageDl, onValueChange = {
                            packageDl = it; prefs.edit().putString("pkgDl", it).apply()
                        }, label = { Text("Package client 0.3.DL") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(onClick = { gamePicker.launch(gameTree) }, modifier = Modifier.fillMaxWidth()) {
                            Text("SÉLECTIONNER LE DOSSIER GTA")
                        }
                        Text("SAF : ${gameTree?.lastPathSegment ?: "non configuré"}", color = Muted)
                        Spacer(Modifier.height(10.dp))
                        Text("Le pseudo et le serveur sont enregistrés dans J2K'. Leur application automatique dépend des options exposées par chaque client SA-MP.", color = Muted, style = MaterialTheme.typography.bodySmall)
                        Text("Android peut bloquer certains dossiers Android/data ou Android/obb. Le launcher respecte les autorisations accordées par le sélecteur système.", color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

private fun loadPacks(context: android.content.Context): List<ModPack> {
    val root = File(context.filesDir, "modpacks").apply { mkdirs() }
    return root.listFiles()?.filter { it.isDirectory }?.map { ModPack(it) }?.sortedBy { it.name } ?: emptyList()
}

private fun safePackName(raw: String): String {
    val cleaned = raw.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_").trim('_')
    return cleaned.take(48).ifBlank { "pack_${System.currentTimeMillis()}" }
}

private fun newPack(context: android.content.Context, name: String): File {
    val root = File(context.filesDir, "modpacks").apply { mkdirs() }
    var target = File(root, name)
    var n = 2
    while (target.exists()) { target = File(root, "${name}_$n"); n++ }
    target.mkdirs()
    return target
}

private fun importZip(context: android.content.Context, uri: Uri): String {
    return try {
        val name = DocumentFile.fromSingleUri(context, uri)?.name ?: "mod.zip"
        val target = newPack(context, safePackName(name))
        context.contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val normalized = entry.name.replace('\\', '/')
                    require(!normalized.startsWith("/") && normalized.split('/').none { it == ".." }) {
                        "Chemin interdit dans l'archive"
                    }
                    val out = File(target, normalized).canonicalFile
                    require(out.path.startsWith(target.canonicalPath + File.separator) || out == target) {
                        "Chemin ZIP invalide"
                    }
                    if (entry.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { zip.copyTo(it) }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        } ?: error("Archive illisible")
        "Pack ZIP importé : ${target.name}"
    } catch (e: Exception) { "Échec import ZIP : ${e.message}" }
}

private fun importFolder(context: android.content.Context, uri: Uri): String {
    return try {
        val source = DocumentFile.fromTreeUri(context, uri) ?: error("Dossier inaccessible")
        val target = newPack(context, safePackName(source.name ?: "mod_folder"))
        copyDocumentFolder(context, source, target)
        "Dossier importé : ${target.name}"
    } catch (e: Exception) { "Échec import dossier : ${e.message}" }
}

private fun copyDocumentFolder(context: android.content.Context, source: DocumentFile, target: File) {
    source.listFiles().forEach { child ->
        val name = child.name ?: return@forEach
        require(name != "." && name != ".." && !name.contains('/')) { "Nom de fichier invalide" }
        val out = File(target, name).canonicalFile
        require(out.path.startsWith(target.canonicalPath + File.separator)) { "Chemin invalide" }
        if (child.isDirectory) {
            out.mkdirs()
            copyDocumentFolder(context, child, out)
        } else if (child.isFile) {
            out.parentFile?.mkdirs()
            context.contentResolver.openInputStream(child.uri)?.use { input ->
                out.outputStream().use { input.copyTo(it) }
            } ?: error("Impossible de lire $name")
        }
    }
}

private fun walkPayload(pack: ModPack): List<Pair<File, String>> {
    return pack.folder.walkTopDown()
        .filter { it.isFile && it.name != "j2k.properties" && it.name != ".j2k-installed.properties" }
        .map { file -> file to file.relativeTo(pack.folder).invariantSeparatorsPath }
        .toList()
}

private fun findOrCreateFile(root: DocumentFile, relative: String): DocumentFile {
    val parts = relative.split('/').filter { it.isNotBlank() }
    require(parts.isNotEmpty() && parts.none { it == "." || it == ".." }) { "Chemin cible invalide" }
    var current = root
    parts.dropLast(1).forEach { part ->
        var dir = current.findFile(part)
        if (dir == null) dir = current.createDirectory(part) ?: error("Création dossier impossible : $part")
        require(dir.isDirectory) { "Un fichier bloque le dossier $part" }
        current = dir
    }
    val fileName = parts.last()
    val existing = current.findFile(fileName)
    if (existing != null && existing.isDirectory) error("Un dossier bloque le fichier $fileName")
    return existing ?: (current.createFile("application/octet-stream", fileName)
        ?: error("Création fichier impossible : $fileName"))
}

private fun backupRoot(context: android.content.Context, pack: ModPack) =
    File(context.filesDir, "backups/${pack.id}").apply { mkdirs() }

private fun installPack(context: android.content.Context, treeUri: Uri, pack: ModPack): String {
    return try {
        require(!pack.installed) { "Pack déjà installé" }
        val gameRoot = DocumentFile.fromTreeUri(context, treeUri) ?: error("Dossier GTA inaccessible")
        require(gameRoot.isDirectory) { "La destination n'est pas un dossier" }
        val payload = walkPayload(pack)
        require(payload.isNotEmpty()) { "Le pack ne contient aucun fichier installable" }

        // Avoid two active packs owning the same relative path.
        val allPacks = loadPacks(context).filter { it.id != pack.id && it.installed }
        val occupied = allPacks.flatMap { installedPaths(it) }.toSet()
        val conflicts = payload.map { it.second }.filter { it in occupied }
        require(conflicts.isEmpty()) { "Conflit avec un autre pack : ${conflicts.firstOrNull()}" }

        val backup = backupRoot(context, pack)
        val props = Properties()
        val completed = mutableListOf<String>()
        try {
            payload.forEach { (source, relative) ->
                val existing = findExisting(gameRoot, relative)
                val existed = existing != null
                props.setProperty(encoded(relative), if (existed) "1" else "0")
                if (existing != null) {
                    val backupFile = File(backup, relative)
                    backupFile.parentFile?.mkdirs()
                    context.contentResolver.openInputStream(existing.uri)?.use { input ->
                        backupFile.outputStream().use { input.copyTo(it) }
                    } ?: error("Sauvegarde impossible : $relative")
                }
                val destination = existing ?: findOrCreateFile(gameRoot, relative)
                // Include this path before writing so rollback also handles a partial write.
                completed.add(relative)
                context.contentResolver.openOutputStream(destination.uri, "wt")?.use { output ->
                    source.inputStream().use { it.copyTo(output) }
                } ?: error("Écriture impossible : $relative")
            }
            File(pack.folder, ".j2k-installed.properties").outputStream().use { props.store(it, "J2K installed files") }
            "Pack installé : ${pack.name} (${completed.size} fichiers)"
        } catch (e: Exception) {
            // Best-effort rollback if any individual write fails.
            completed.asReversed().forEach { relative ->
                runCatching {
                    val target = findExisting(gameRoot, relative) ?: return@runCatching
                    if (props.getProperty(encoded(relative)) == "1") {
                        val b = File(backup, relative)
                        if (b.exists()) context.contentResolver.openOutputStream(target.uri, "wt")?.use { out -> b.inputStream().use { it.copyTo(out) } }
                    } else target.delete()
                }
            }
            throw e
        }
    } catch (e: Exception) { "Installation échouée : ${e.message}" }
}

private fun installedPaths(pack: ModPack): List<String> {
    val p = Properties()
    val marker = File(pack.folder, ".j2k-installed.properties")
    if (!marker.exists()) return emptyList()
    marker.inputStream().use { p.load(it) }
    return p.stringPropertyNames().mapNotNull { decode(it) }
}

private fun uninstallPack(context: android.content.Context, treeUri: Uri, pack: ModPack): String {
    return try {
        val gameRoot = DocumentFile.fromTreeUri(context, treeUri) ?: error("Dossier GTA inaccessible")
        val marker = File(pack.folder, ".j2k-installed.properties")
        require(marker.exists()) { "Aucune sauvegarde d'installation trouvée" }
        val props = Properties()
        marker.inputStream().use { props.load(it) }
        val backup = backupRoot(context, pack)
        var restored = 0
        props.stringPropertyNames().forEach { key ->
            val relative = decode(key) ?: return@forEach
            val target = findExisting(gameRoot, relative)
            if (props.getProperty(key) == "1") {
                val saved = File(backup, relative)
                require(saved.exists()) { "Sauvegarde manquante : $relative" }
                val actual = target ?: findOrCreateFile(gameRoot, relative)
                context.contentResolver.openOutputStream(actual.uri, "wt")?.use { out ->
                    saved.inputStream().use { it.copyTo(out) }
                } ?: error("Restauration impossible : $relative")
            } else {
                target?.delete()
            }
            restored++
        }
        marker.delete()
        backup.deleteRecursively()
        "Pack désinstallé : $restored fichiers restaurés"
    } catch (e: Exception) { "Restauration échouée : ${e.message}" }
}

private fun findExisting(root: DocumentFile, relative: String): DocumentFile? {
    val parts = relative.split('/').filter { it.isNotBlank() }
    if (parts.isEmpty() || parts.any { it == "." || it == ".." }) return null
    var current = root
    parts.forEachIndexed { index, part ->
        val next = current.findFile(part) ?: return null
        if (index < parts.lastIndex && !next.isDirectory) return null
        current = next
    }
    return current.takeIf { it.isFile }
}

private fun encoded(value: String): String = Base64.getUrlEncoder().withoutPadding()
    .encodeToString(value.toByteArray(Charsets.UTF_8))
private fun decode(value: String): String? = runCatching {
    String(Base64.getUrlDecoder().decode(value), Charsets.UTF_8)
}.getOrNull()

@Composable
private fun PageTitle(title: String, subtitle: String) {
    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    Text(subtitle, color = Muted)
    Spacer(Modifier.height(14.dp))
}

@Composable
private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(15.dp), content = content)
    }
}

@Composable
private fun SelectCard(version: String, selected: Boolean, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp).clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF173522) else Panel),
        shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("SA-MP $version", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
            if (selected) Icon(Icons.Default.CheckCircle, null, tint = Green)
        }
    }
}
